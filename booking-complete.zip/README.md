# Booking Platform

This project is a Booking.com-style travel booking platform built with Next.js 14.

Follow README instructions in the project root to run locally.
