// lib/currency.ts - uses exchangerate.host for conversion (no API key)
export async function getExchangeRate(base = "USD", to = "USD") {
  if (base === to) return 1;
  const cacheKey = `${base}_${to}` as string;
  // @ts-ignore
  if (!global._fx_cache) global._fx_cache = {};
  const cache = global._fx_cache;
  if (cache[cacheKey] && Date.now() - cache[cacheKey].ts < 5 * 60 * 1000) {
    return cache[cacheKey].rate;
  }

  const url = `https://api.exchangerate.host/convert?from=${encodeURIComponent(base)}&to=${encodeURIComponent(to)}&amount=1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to fetch exchange rate");
  const data = await res.json();
  const rate = data?.result ?? data?.info?.rate ?? 1;
  cache[cacheKey] = { rate, ts: Date.now() };
  return rate;
}

export async function convertAmount(amountUSD: number, toCurrency = "USD") {
  if (toCurrency === "USD") return amountUSD;
  const rate = await getExchangeRate("USD", toCurrency);
  return amountUSD * rate;
}
