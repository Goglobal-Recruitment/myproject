// lib/cache.ts - simple in-memory TTL cache
type CacheEntry<T> = {
  value: T;
  expiresAt: number;
};

const STORE: { [key: string]: CacheEntry<any> } = {};

export function getFromCache<T>(key: string): T | null {
  const entry = STORE[key];
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    delete STORE[key];
    return null;
  }
  return entry.value as T;
}

export function setCache<T>(key: string, value: T, ttlSeconds = 300) {
  STORE[key] = { value, expiresAt: Date.now() + ttlSeconds * 1000 };
}

export function clearCache(key: string) {
  delete STORE[key];
}
