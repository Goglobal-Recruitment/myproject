// lib/pricing.ts - central pricing logic (kids under 18 fly free, insurance fixed $600, vouchers)
import { convertAmount } from "./currency";
// @ts-ignore
import vouchersDb from "@/data/vouchers.json";

export type Voucher = {
  code: string;
  type: "percent" | "fixed";
  value: number;
  expiry?: string;
};

export function validateVoucher(code?: string): { valid: boolean; voucher?: Voucher; message?: string } {
  if (!code) return { valid: false, message: "No code provided" };
  // @ts-ignore
  const v = vouchersDb[code?.toUpperCase()];
  if (!v) return { valid: false, message: "Invalid voucher" };
  const now = new Date();
  if (v.expiry && new Date(v.expiry) < now) return { valid: false, message: "Voucher expired" };
  return { valid: true, voucher: v as Voucher };
}

export type PriceInputs = {
  hotelPerNightUSD?: number;
  nights?: number;
  flightPerAdultUSD?: number;
  adults: number;
  children: number;
  insuranceSelected?: boolean;
  voucherCode?: string;
  currency?: string;
};

export async function calculateTotal(inputs: PriceInputs) {
  const {
    hotelPerNightUSD = 0,
    nights = 0,
    flightPerAdultUSD = 0,
    adults,
    children,
    insuranceSelected,
    voucherCode,
    currency = "USD",
  } = inputs;

  const hotelTotalUSD = hotelPerNightUSD * nights;
  const flightTotalUSD = flightPerAdultUSD * adults; // children under 18 are free for flights
  const insuranceUSD = insuranceSelected ? 600 : 0;

  let subtotalUSD = hotelTotalUSD + flightTotalUSD + insuranceUSD;

  const voucherResult = validateVoucher(voucherCode);
  let discountUSD = 0;
  if (voucherResult.valid && voucherResult.voucher) {
    const v = voucherResult.voucher;
    if (v.type === "percent") {
      discountUSD = (subtotalUSD * v.value) / 100;
    } else {
      discountUSD = v.value;
    }
  }

  if (discountUSD > subtotalUSD) discountUSD = subtotalUSD;

  const totalAfterDiscountUSD = subtotalUSD - discountUSD;

  const convertedTotal = await convertAmount(totalAfterDiscountUSD, currency);

  const converted = {
    hotelUSD: hotelTotalUSD,
    flightsUSD: flightTotalUSD,
    insuranceUSD,
    discountUSD,
    totalUSD: totalAfterDiscountUSD,
    hotel: await convertAmount(hotelTotalUSD, currency),
    flights: await convertAmount(flightTotalUSD, currency),
    insurance: await convertAmount(insuranceUSD, currency),
    discount: await convertAmount(discountUSD, currency),
    total: convertedTotal,
    currency,
    voucher: voucherResult.valid ? voucherResult.voucher : null,
  };

  return converted;
}
