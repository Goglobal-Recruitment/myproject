export const flights = [
  {
    id: "F-001",
    airline: "AirLocal",
    flightNumber: "AL123",
    origin: "JNB",
    destination: "CPT",
    departureAt: "2025-10-01T08:00:00Z",
    arrivalAt: "2025-10-01T09:30:00Z",
    durationMinutes: 90,
    baseFareUSD: 120,
    stops: 0,
  },
  {
    id: "F-002",
    airline: "GlobalAir",
    flightNumber: "GA789",
    origin: "JNB",
    destination: "LHR",
    departureAt: "2025-10-01T20:00:00Z",
    arrivalAt: "2025-10-02T08:00:00Z",
    durationMinutes: 720,
    baseFareUSD: 650,
    stops: 1,
  }
];