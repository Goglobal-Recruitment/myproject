export const fallbackHotels = [
  {
    title: "Mock Hotel Paris",
    location: "Paris, France",
    price: "€120 per night",
    rating: "8.5",
    image: "https://picsum.photos/400/250?random=1",
  },
  {
    title: "Demo Resort London",
    location: "London, UK",
    price: "£95 per night",
    rating: "9.1",
    image: "https://picsum.photos/400/250?random=2",
  },
  {
    title: "Test Inn New York",
    location: "New York, USA",
    price: "$150 per night",
    rating: "7.8",
    image: "https://picsum.photos/400/250?random=3",
  },
];
